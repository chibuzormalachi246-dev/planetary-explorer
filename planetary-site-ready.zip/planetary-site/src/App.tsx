import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { CHAPTERS, PLANETS, buildSolarSystem, chapterT } from "./solarSystem";

const chapters = CHAPTERS;
const BASE_FOV = 66;

/* ------------------------------------------------------------------ */
/*  Custom Shaders                                                    */
/* ------------------------------------------------------------------ */

const ChromaticAberrationShader = {
  uniforms: {
    tDiffuse: { value: null },
    amount: { value: 0.003 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float amount;
    varying vec2 vUv;
    void main() {
      vec2 dir = vUv - 0.5;
      float d = length(dir);
      float offset = amount * d;
      float r = texture2D(tDiffuse, vUv + dir * offset).r;
      float g = texture2D(tDiffuse, vUv).g;
      float b = texture2D(tDiffuse, vUv - dir * offset).b;
      gl_FragColor = vec4(r, g, b, 1.0);
    }
  `,
};

const FilmGrainVignetteShader = {
  uniforms: {
    tDiffuse: { value: null },
    time: { value: 0 },
    grainIntensity: { value: 0.06 },
    vignetteStrength: { value: 0.55 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float time;
    uniform float grainIntensity;
    uniform float vignetteStrength;
    varying vec2 vUv;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
    }

    void main() {
      vec4 color = texture2D(tDiffuse, vUv);
      float grain = (hash(vUv * 1024.0 + time * 37.0) - 0.5) * grainIntensity;
      color.rgb += grain;
      vec2 uv = vUv * (1.0 - vUv);
      float vig = uv.x * uv.y * 15.0;
      vig = pow(vig, vignetteStrength);
      color.rgb *= vig;
      gl_FragColor = color;
    }
  `,
};

const glowTubeVertexShader = /* glsl */ `
  varying vec2 vUv;
  varying float vDist;
  void main() {
    vUv = uv;
    vDist = position.z;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const glowTubeFragmentShader = /* glsl */ `
  uniform float time;
  uniform float progress;
  uniform float pathLength;
  varying vec2 vUv;
  varying float vDist;
  void main() {
    float wave = sin(vUv.y * 120.0 - time * 3.0 + vDist * 0.06) * 0.5 + 0.5;
    float pulse = sin(vUv.y * 18.0 - time * 1.6) * 0.5 + 0.5;
    float fade = smoothstep(0.0, 0.06, vUv.x) * smoothstep(1.0, 0.94, vUv.x);
    float alpha = (wave * 0.14 + pulse * 0.06 + 0.03) * fade;
    float distFade = smoothstep(progress * pathLength, progress * pathLength - 150.0, -vDist);
    vec3 cyan = vec3(0.0, 0.86, 1.0);
    vec3 violet = vec3(0.52, 0.18, 0.95);
    vec3 col = mix(cyan, violet, vUv.y);
    gl_FragColor = vec4(col, alpha * distFade);
  }
`;

/* ------------------------------------------------------------------ */
/*  App Component                                                     */
/* ------------------------------------------------------------------ */

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const minimapRef = useRef<HTMLCanvasElement | null>(null);
  const progressBarRef = useRef<HTMLDivElement | null>(null);
  const progressTextRef = useRef<HTMLSpanElement | null>(null);
  const rangeTextRef = useRef<HTMLSpanElement | null>(null);
  const speedTextRef = useRef<HTMLSpanElement | null>(null);
  const headingTextRef = useRef<HTMLSpanElement | null>(null);
  const proximityTextRef = useRef<HTMLSpanElement | null>(null);
  const contentRefs = useRef<Array<HTMLDivElement | null>>([]);
  const labelRefs = useRef<Array<HTMLDivElement | null>>([]);
  const labelDistRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const navRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const glitchOverlayRef = useRef<HTMLDivElement | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (loading) return;
    const canvas = canvasRef.current;
    const minimapCanvas = minimapRef.current;
    if (!canvas || !minimapCanvas) return;

    const isMobile = window.innerWidth < 720;

    /* ------------------------------------------------------------ */
    /*  Scene + Renderer                                              */
    /* ------------------------------------------------------------ */
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030307, 0.006);
    const camera = new THREE.PerspectiveCamera(
      BASE_FOV,
      window.innerWidth / window.innerHeight,
      0.1,
      1600,
    );
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      });
    } catch {
      canvas.dataset.webgl = "unavailable";
      return;
    }
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(
      Math.min(window.devicePixelRatio || 1, isMobile ? 1.2 : 1.6),
    );
    renderer.setClearColor(0x030307, 1);

    /* ------------------------------------------------------------ */
    /*  Post-processing                                               */
    /* ------------------------------------------------------------ */
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      0.8,
      0.4,
      0.2,
    );
    composer.addPass(bloomPass);
    const chromaticPass = new ShaderPass(ChromaticAberrationShader);
    composer.addPass(chromaticPass);
    const grainVigPass = new ShaderPass(FilmGrainVignetteShader);
    composer.addPass(grainVigPass);
    composer.addPass(new OutputPass());

    /* ------------------------------------------------------------ */
    /*  Lighting                                                      */
    /* ------------------------------------------------------------ */
    scene.add(new THREE.AmbientLight(0x0d1a2f, 1.5));
    const keyLight = new THREE.PointLight(0x00d9ff, 60, 72, 1.8);
    const fillLight = new THREE.PointLight(0x893bff, 48, 80, 1.7);
    scene.add(keyLight, fillLight);

    /* ------------------------------------------------------------ */
    /*  Seeded Random                                                 */
    /* ------------------------------------------------------------ */
    let seed = 1729;
    const random = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296;
      return seed / 4294967296;
    };

    /* ------------------------------------------------------------ */
    /*  Spline Path — grand tour through nine worlds                  */
    /* ------------------------------------------------------------ */
    const pathPoints = [
      new THREE.Vector3(0, 0, 6),
      new THREE.Vector3(6, 4, -52),
      new THREE.Vector3(-10, -5, -118),
      new THREE.Vector3(10, 7, -188),
      new THREE.Vector3(-7, -2, -258),
      new THREE.Vector3(6, 5, -328),
      new THREE.Vector3(-9, -4, -398),
      new THREE.Vector3(8, 6, -468),
      new THREE.Vector3(-6, -1, -538),
      new THREE.Vector3(5, 3, -608),
      new THREE.Vector3(0, 0, -690),
    ];
    const curve = new THREE.CatmullRomCurve3(pathPoints, false, "catmullrom", 0.5);
    const PATH_LENGTH = 700;

    /* ------------------------------------------------------------ */
    /*  Wireframe Track                                               */
    /* ------------------------------------------------------------ */
    scene.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(curve, 520, 0.9, 8, false),
        new THREE.MeshBasicMaterial({
          color: 0x1e2e44,
          wireframe: true,
          transparent: true,
          opacity: 0.13,
          depthWrite: false,
        }),
      ),
    );

    /* ------------------------------------------------------------ */
    /*  Animated Glow Tube                                            */
    /* ------------------------------------------------------------ */
    const glowTube = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 480, 1.8, 16, false),
      new THREE.ShaderMaterial({
        uniforms: {
          time: { value: 0 },
          progress: { value: 0 },
          pathLength: { value: PATH_LENGTH },
        },
        vertexShader: glowTubeVertexShader,
        fragmentShader: glowTubeFragmentShader,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      }),
    );
    scene.add(glowTube);

    /* ------------------------------------------------------------ */
    /*  Portals                                                       */
    /* ------------------------------------------------------------ */
    const portalAxis = new THREE.Vector3(0, 0, 1);
    const ringGeo = new THREE.TorusGeometry(3.45, 0.035, 8, 96);
    const haloGeo = new THREE.TorusGeometry(3.95, 0.014, 6, 96);
    const structuralGeo = new THREE.TorusGeometry(5.2, 0.013, 6, 112);
    const innerRingGeo = new THREE.TorusGeometry(2.2, 0.018, 6, 72);
    const markerGeo = new THREE.BoxGeometry(0.045, 0.32, 0.045);

    const cyanMat = new THREE.MeshBasicMaterial({
      color: 0x29dcff,
      transparent: true,
      opacity: 0.88,
      depthWrite: false,
      toneMapped: false,
    });
    const violetMat = new THREE.MeshBasicMaterial({
      color: 0xb46aff,
      transparent: true,
      opacity: 0.86,
      depthWrite: false,
      toneMapped: false,
    });
    const cyanHaloMat = new THREE.MeshBasicMaterial({
      color: 0x24c7ff,
      transparent: true,
      opacity: 0.32,
      depthWrite: false,
      toneMapped: false,
    });
    const violetHaloMat = new THREE.MeshBasicMaterial({
      color: 0x9b4dff,
      transparent: true,
      opacity: 0.31,
      depthWrite: false,
      toneMapped: false,
    });

    const portalCount = isMobile ? 30 : 42;
    const portalT: number[] = [];
    const portals: Array<{
      frame: THREE.Group;
      markers: THREE.Group;
      phase: number;
      direction: number;
    }> = [];

    for (let i = 0; i < portalCount; i++) {
      const t = (i + 1) / (portalCount + 1);
      portalT.push(t);
      const pos = curve.getPointAt(t);
      const tangent = curve.getTangentAt(t).normalize();
      const isCyan = i % 2 === 0;
      const frame = new THREE.Group();
      const marks = new THREE.Group();

      frame.position.copy(pos);
      frame.quaternion.setFromUnitVectors(portalAxis, tangent);

      const halo = new THREE.Mesh(haloGeo, isCyan ? cyanHaloMat : violetHaloMat);
      halo.position.z = -0.08;
      frame.add(halo);

      const ring = new THREE.Mesh(ringGeo, isCyan ? cyanMat : violetMat);
      frame.add(ring);

      if (i % 3 === 0) {
        const inner = new THREE.Mesh(innerRingGeo, isCyan ? violetHaloMat : cyanHaloMat);
        frame.add(inner);
      }
      if (i % 4 === 1) {
        const structural = new THREE.Mesh(structuralGeo, isCyan ? violetHaloMat : cyanHaloMat);
        structural.rotation.z = Math.PI / 12;
        frame.add(structural);
      }

      const markerInstances = new THREE.InstancedMesh(
        markerGeo,
        isCyan ? cyanMat : violetMat,
        16,
      );
      const markerTransform = new THREE.Object3D();
      for (let m = 0; m < 16; m++) {
        const angle = (m / 16) * Math.PI * 2;
        markerTransform.position.set(
          Math.cos(angle) * 3.95,
          Math.sin(angle) * 3.95,
          0.015,
        );
        markerTransform.rotation.set(0, 0, angle);
        markerTransform.updateMatrix();
        markerInstances.setMatrixAt(m, markerTransform.matrix);
      }
      markerInstances.instanceMatrix.needsUpdate = true;
      markerInstances.computeBoundingSphere();
      marks.add(markerInstances);
      frame.add(marks);

      scene.add(frame);
      portals.push({
        frame,
        markers: marks,
        phase: t * Math.PI * 5,
        direction: i % 2 === 0 ? 1 : -1,
      });
    }

    /* ------------------------------------------------------------ */
    /*  Solar System — nine realistic worlds                          */
    /* ------------------------------------------------------------ */
    const solar = buildSolarSystem(scene, curve, random, isMobile);

    /* ------------------------------------------------------------ */
    /*  Particles (stars)                                             */
    /* ------------------------------------------------------------ */
    const starCount = isMobile ? 1800 : 3200;
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);
    const cyan = new THREE.Color(0x24cfff);
    const violet = new THREE.Color(0x9a62ff);
    const white = new THREE.Color(0xddeeff);
    const palette = [cyan, violet, white, cyan, violet, white];

    for (let i = 0; i < starCount; i++) {
      const o = i * 3;
      starPositions[o] = (random() - 0.5) * 320;
      starPositions[o + 1] = (random() - 0.5) * 220;
      starPositions[o + 2] = 40 - random() * 820;
      const c = palette[Math.floor(random() * palette.length)];
      starColors[o] = c.r;
      starColors[o + 1] = c.g;
      starColors[o + 2] = c.b;
    }

    const starGeo = new THREE.BufferGeometry();
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPositions, 3));
    starGeo.setAttribute("color", new THREE.BufferAttribute(starColors, 3));
    const stars = new THREE.Points(
      starGeo,
      new THREE.PointsMaterial({
        size: 0.16,
        vertexColors: true,
        transparent: true,
        opacity: 0.78,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        sizeAttenuation: true,
      }),
    );
    scene.add(stars);

    /* ------------------------------------------------------------ */
    /*  Warp Streaks                                                  */
    /* ------------------------------------------------------------ */
    const streakCount = isMobile ? 400 : 800;
    const streakPositions = new Float32Array(streakCount * 3);
    const streakVelocities = new Float32Array(streakCount * 3);
    const streakLifetimes = new Float32Array(streakCount);
    const streakColors = new Float32Array(streakCount * 3);

    for (let i = 0; i < streakCount; i++) {
      const o = i * 3;
      streakPositions[o] = (random() - 0.5) * 12;
      streakPositions[o + 1] = (random() - 0.5) * 12;
      streakPositions[o + 2] = random() * -12;
      streakVelocities[o] = (random() - 0.5) * 0.3;
      streakVelocities[o + 1] = (random() - 0.5) * 0.3;
      streakVelocities[o + 2] = -(1.5 + random() * 3);
      streakLifetimes[i] = random();
      const c = random() > 0.45 ? cyan : violet;
      streakColors[o] = c.r;
      streakColors[o + 1] = c.g;
      streakColors[o + 2] = c.b;
    }

    const streakGeo = new THREE.BufferGeometry();
    streakGeo.setAttribute("position", new THREE.BufferAttribute(streakPositions, 3));
    streakGeo.setAttribute("color", new THREE.BufferAttribute(streakColors, 3));
    const streaks = new THREE.Points(
      streakGeo,
      new THREE.PointsMaterial({
        size: 0.06,
        vertexColors: true,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        sizeAttenuation: true,
      }),
    );
    scene.add(streaks);

    /* ------------------------------------------------------------ */
    /*  Artifacts                                                     */
    /* ------------------------------------------------------------ */
    const artifactGeos = [
      new THREE.OctahedronGeometry(1, 0),
      new THREE.IcosahedronGeometry(1, 0),
      new THREE.TetrahedronGeometry(1, 0),
    ];
    const solidMat = new THREE.MeshStandardMaterial({
      color: 0x18283b,
      emissive: 0x07182c,
      emissiveIntensity: 0.6,
      roughness: 0.22,
      metalness: 0.82,
    });
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0x327b9b,
      wireframe: true,
      transparent: true,
      opacity: 0.52,
      toneMapped: false,
    });
    const artifacts: Array<{
      mesh: THREE.Mesh;
      baseY: number;
      phase: number;
      speedX: number;
      speedY: number;
    }> = [];

    for (let i = 0; i < 40; i++) {
      const t = random();
      const pt = curve.getPointAt(t);
      const mesh = new THREE.Mesh(
        artifactGeos[i % artifactGeos.length],
        i % 3 === 0 ? wireMat : solidMat,
      );
      const baseY = pt.y + (random() - 0.5) * 44;
      mesh.position.set(
        pt.x + (random() - 0.5) * 52,
        baseY,
        pt.z + (random() - 0.5) * 24,
      );
      mesh.rotation.set(random() * Math.PI, random() * Math.PI, random() * Math.PI);
      mesh.scale.setScalar(0.3 + random() * 1.15);
      scene.add(mesh);
      artifacts.push({
        mesh,
        baseY,
        phase: random() * Math.PI * 2,
        speedX: (random() - 0.5) * 0.44,
        speedY: (random() - 0.5) * 0.44,
      });
    }

    /* ------------------------------------------------------------ */
    /*  Energy Stream (glowing line along path)                       */
    /* ------------------------------------------------------------ */
    const streamPoints = curve.getPoints(700);
    const streamGeo = new THREE.BufferGeometry().setFromPoints(streamPoints);
    const streamColors = new Float32Array(streamPoints.length * 3);
    for (let i = 0; i < streamPoints.length; i++) {
      const t = i / streamPoints.length;
      const c = new THREE.Color().lerpColors(cyan, violet, t);
      streamColors[i * 3] = c.r;
      streamColors[i * 3 + 1] = c.g;
      streamColors[i * 3 + 2] = c.b;
    }
    streamGeo.setAttribute("color", new THREE.BufferAttribute(streamColors, 3));
    scene.add(
      new THREE.Line(
        streamGeo,
        new THREE.LineBasicMaterial({
          vertexColors: true,
          transparent: true,
          opacity: 0.18,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          linewidth: 1,
        }),
      ),
    );

    /* ------------------------------------------------------------ */
    /*  Core Nexus                                                    */
    /* ------------------------------------------------------------ */
    const core = new THREE.Group();
    core.position.copy(curve.getPointAt(0.988));
    const coreOrb = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.72, 1),
      new THREE.MeshBasicMaterial({
        color: 0x8eeeff,
        wireframe: true,
        transparent: true,
        opacity: 0.92,
        toneMapped: false,
      }),
    );
    const coreInner = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 16, 16),
      new THREE.MeshBasicMaterial({
        color: 0x66eeff,
        transparent: true,
        opacity: 0.15,
        toneMapped: false,
      }),
    );
    const coreHalo1 = new THREE.Mesh(
      new THREE.TorusGeometry(2.45, 0.02, 6, 96),
      cyanHaloMat,
    );
    const coreHalo2 = new THREE.Mesh(
      new THREE.TorusGeometry(3.2, 0.014, 6, 112),
      violetHaloMat,
    );
    coreHalo2.rotation.x = Math.PI / 3;
    const coreHalo3 = new THREE.Mesh(
      new THREE.TorusGeometry(1.8, 0.015, 6, 72),
      new THREE.MeshBasicMaterial({
        color: 0x55ddff,
        transparent: true,
        opacity: 0.22,
        depthWrite: false,
        toneMapped: false,
      }),
    );
    coreHalo3.rotation.y = Math.PI / 5;
    core.add(coreOrb, coreInner, coreHalo1, coreHalo2, coreHalo3);
    scene.add(core);

    /* ------------------------------------------------------------ */
    /*  Minimap Canvas                                                */
    /* ------------------------------------------------------------ */
    const minimapCtx = minimapCanvas.getContext("2d")!;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const minimapW = 60;
    const minimapH = 150;
    minimapCanvas.width = minimapW * dpr;
    minimapCanvas.height = minimapH * dpr;
    minimapCanvas.style.width = `${minimapW}px`;
    minimapCanvas.style.height = `${minimapH}px`;
    minimapCtx.scale(dpr, dpr);

    const planetDots = PLANETS.map((p) => ({
      t: chapterT(p.chapterIndex),
      color: chapters[p.chapterIndex].accent,
    }));

    const drawMinimap = (progress: number) => {
      minimapCtx.clearRect(0, 0, minimapW, minimapH);
      minimapCtx.strokeStyle = "rgba(255,255,255,0.1)";
      minimapCtx.lineWidth = 1;
      minimapCtx.beginPath();
      for (let i = 0; i <= 100; i++) {
        const t = i / 100;
        const pt = curve.getPointAt(t);
        const x = 30 + (pt.x / 12) * 20;
        const y = 8 + (1 - t) * 134;
        if (i === 0) minimapCtx.moveTo(x, y);
        else minimapCtx.lineTo(x, y);
      }
      minimapCtx.stroke();

      for (const dot of planetDots) {
        const dotPt = curve.getPointAt(dot.t);
        const dx = 30 + (dotPt.x / 12) * 20;
        const y = 8 + (1 - dot.t) * 134;
        minimapCtx.fillStyle = dot.color;
        minimapCtx.globalAlpha = 0.85;
        minimapCtx.beginPath();
        minimapCtx.arc(dx, y, 1.8, 0, Math.PI * 2);
        minimapCtx.fill();
        minimapCtx.globalAlpha = 1;
      }

      const py = 8 + (1 - progress) * 134;
      const gradient = minimapCtx.createRadialGradient(30, py, 0, 30, py, 8);
      gradient.addColorStop(0, "rgba(42,220,255,0.9)");
      gradient.addColorStop(1, "rgba(42,220,255,0)");
      minimapCtx.fillStyle = gradient;
      minimapCtx.beginPath();
      minimapCtx.arc(30, py, 8, 0, Math.PI * 2);
      minimapCtx.fill();
      minimapCtx.fillStyle = "#29dcff";
      minimapCtx.beginPath();
      minimapCtx.arc(30, py, 2.5, 0, Math.PI * 2);
      minimapCtx.fill();
    };

    /* ------------------------------------------------------------ */
    /*  State + Events                                                */
    /* ------------------------------------------------------------ */
    const camTarget = new THREE.Vector3();
    const lookTarget = new THREE.Vector3();
    const prevCamTarget = new THREE.Vector3();
    const projVec = new THREE.Vector3();
    const toPlanet = new THREE.Vector3();
    const camDir = new THREE.Vector3();
    let targetProgress = 0;
    let scrollProgress = 0;
    let prevScrollProgress = 0;
    let scrollSpeed = 0;
    let targetMouseX = 0;
    let targetMouseY = 0;
    let mouseX = 0;
    let mouseY = 0;
    let camRoll = 0;
    let fovCurrent = BASE_FOV;
    let frameId = 0;
    let lastActiveChapter = 0;
    const clock = new THREE.Clock();
    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    const motionScale = reducedMotion ? 0.14 : 1;

    const updateScrollTarget = () => {
      const max = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight,
      );
      targetProgress = THREE.MathUtils.clamp(window.scrollY / max, 0, 1);
    };

    const handlePointerMove = (e: PointerEvent) => {
      targetMouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetMouseY = -(e.clientY / window.innerHeight - 0.5) * 2;
    };

    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, w < 720 ? 1.2 : 1.6));
      composer.setSize(w, h);
      bloomPass.resolution.set(w, h);
      updateScrollTarget();
    };

    updateScrollTarget();
    window.addEventListener("scroll", updateScrollTarget, { passive: true });
    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("resize", handleResize);

    /* ------------------------------------------------------------ */
    /*  Glitch trigger                                                */
    /* ------------------------------------------------------------ */
    const triggerGlitch = () => {
      const overlay = glitchOverlayRef.current;
      if (!overlay) return;
      overlay.classList.remove("is-glitching");
      void overlay.offsetWidth;
      overlay.classList.add("is-glitching");
      setTimeout(() => overlay.classList.remove("is-glitching"), 500);
    };

    /* ------------------------------------------------------------ */
    /*  Animate                                                       */
    /* ------------------------------------------------------------ */
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.elapsedTime;
      const easing = reducedMotion ? 1 : 1 - Math.exp(-delta * 5.2);

      prevScrollProgress = scrollProgress;
      scrollProgress += (targetProgress - scrollProgress) * easing;
      scrollSpeed = Math.abs(scrollProgress - prevScrollProgress) / Math.max(delta, 0.001);
      mouseX += (targetMouseX - mouseX) * Math.min(1, delta * 3.5);
      mouseY += (targetMouseY - mouseY) * Math.min(1, delta * 3.5);

      /* HUD */
      const pct = (scrollProgress * 100).toFixed(1);
      if (progressBarRef.current)
        progressBarRef.current.style.transform = `scaleX(${scrollProgress})`;
      if (progressTextRef.current)
        progressTextRef.current.textContent = `${pct.padStart(5, "0")}%`;
      if (rangeTextRef.current) {
        const au = 0.31 + scrollProgress * (39.5 - 0.31);
        rangeTextRef.current.textContent = `${au.toFixed(2).padStart(5, "0")} AU`;
      }
      if (speedTextRef.current) {
        const displaySpeed = Math.min(scrollSpeed * 4200, 9999).toFixed(0);
        speedTextRef.current.textContent = `${displaySpeed.padStart(4, "0")} u/s`;
      }
      if (headingTextRef.current) {
        const boundedH = THREE.MathUtils.clamp(scrollProgress, 0, 0.999);
        const tangentH = curve.getTangentAt(boundedH);
        const angleDeg = ((Math.atan2(tangentH.x, -tangentH.z) * 180) / Math.PI + 360) % 360;
        headingTextRef.current.textContent = `${angleDeg.toFixed(0).padStart(3, "0")}°`;
      }

      /* Chapter transitions */
      let currentChapter = 0;
      contentRefs.current.forEach((box, idx) => {
        if (!box) return;
        const center = idx / (chapters.length - 1);
        const isActive = Math.abs(scrollProgress - center) < 0.048;
        box.classList.toggle("is-active", isActive);
        if (isActive) currentChapter = idx;
      });
      navRefs.current.forEach((btn, idx) => {
        if (!btn) return;
        btn.classList.toggle("is-active", idx === currentChapter);
      });
      if (currentChapter !== lastActiveChapter) {
        lastActiveChapter = currentChapter;
        triggerGlitch();
      }

      /* Camera path */
      const bp = THREE.MathUtils.clamp(scrollProgress, 0, 0.999);
      prevCamTarget.copy(camTarget);
      curve.getPointAt(bp, camTarget);
      curve.getPointAt(Math.min(1, bp + 0.022), lookTarget);
      camTarget.x += mouseX * 0.62;
      camTarget.y += mouseY * 0.48;
      lookTarget.x += mouseX * 0.2;
      lookTarget.y += mouseY * 0.16;

      /* Planet flyby focus — glance toward the nearest world ahead */
      let nearestDist = Infinity;
      let nearestName = "DEEP SPACE";
      camera.getWorldDirection(camDir);
      for (const p of solar.planets) {
        toPlanet.copy(p.group.position).sub(camTarget);
        const dist = toPlanet.length();
        if (dist < nearestDist) {
          nearestDist = dist;
          nearestName = p.def.name;
        }
        if (dist < 46) {
          const facing = toPlanet.normalize().dot(camDir);
          if (facing > 0.25) {
            const pull = (1 - dist / 46) * 0.42 * facing;
            lookTarget.lerp(p.group.position, Math.min(0.5, pull));
          }
        }
      }
      if (proximityTextRef.current) {
        proximityTextRef.current.textContent =
          nearestDist < 70
            ? `${nearestName} · ${String(Math.max(0, Math.round(nearestDist * 4.2))).padStart(3, "0")}Mm`
            : "DEEP SPACE";
      }

      camera.position.copy(camTarget);
      camera.lookAt(lookTarget);

      /* Cinematic banking roll in the turns */
      if (delta > 0.0001) {
        const lateralVel = (camTarget.x - prevCamTarget.x) / delta;
        const rollTarget = THREE.MathUtils.clamp(
          (-lateralVel * 0.004 - mouseX * 0.02) * motionScale,
          -0.09,
          0.09,
        );
        camRoll += (rollTarget - camRoll) * Math.min(1, delta * 3);
        camera.rotateZ(camRoll);
      }

      /* Warp FOV kick */
      const warpIntensity = Math.min(scrollSpeed * 18, 1);
      const fovTarget = BASE_FOV + warpIntensity * 11 * motionScale;
      fovCurrent += (fovTarget - fovCurrent) * Math.min(1, delta * 4);
      if (Math.abs(camera.fov - fovCurrent) > 0.01) {
        camera.fov = fovCurrent;
        camera.updateProjectionMatrix();
      }

      /* Lights */
      keyLight.position.set(camTarget.x - 2, camTarget.y + 3, camTarget.z - 5);
      fillLight.position.set(camTarget.x + 3, camTarget.y - 2, camTarget.z - 3);

      /* Glow tube uniforms */
      const glowMat = glowTube.material as THREE.ShaderMaterial;
      glowMat.uniforms.time.value = elapsed;
      glowMat.uniforms.progress.value = scrollProgress;

      /* Portal pass pulse */
      let portalPulse = 0;
      for (const pt of portalT) {
        const d = Math.abs(scrollProgress - pt);
        if (d < 0.004) portalPulse = Math.max(portalPulse, 1 - d / 0.004);
      }

      /* Dynamic post-processing */
      const targetAberration = 0.001 + Math.min(scrollSpeed * 1.8, 0.012) + portalPulse * 0.006 * motionScale;
      chromaticPass.uniforms.amount.value +=
        (targetAberration - chromaticPass.uniforms.amount.value) * 0.08;
      grainVigPass.uniforms.time.value = elapsed * 37;
      bloomPass.strength = 0.7 + Math.min(scrollSpeed * 4, 0.8) + portalPulse * 0.45 * motionScale;

      /* Portals */
      portals.forEach((p) => {
        p.markers.rotation.z += delta * 0.34 * p.direction * motionScale;
        const pulse = 1 + Math.sin(elapsed * 1.05 + p.phase) * 0.014;
        p.frame.scale.setScalar(pulse);
      });

      /* Solar system */
      solar.update(delta, elapsed, motionScale);

      /* Artifacts */
      artifacts.forEach((a) => {
        a.mesh.rotation.x += a.speedX * delta * motionScale;
        a.mesh.rotation.y += a.speedY * delta * motionScale;
        a.mesh.position.y =
          a.baseY + Math.sin(elapsed * 0.7 + a.phase) * 0.26 * motionScale;
      });

      /* Warp streaks */
      streaks.material.opacity = warpIntensity * 0.65;
      const streakPosArr = streakGeo.attributes.position.array as Float32Array;
      const streakColArr = streakGeo.attributes.color.array as Float32Array;
      for (let i = 0; i < streakCount; i++) {
        const o = i * 3;
        streakLifetimes[i] += delta * (0.6 + warpIntensity * 2.4);
        if (streakLifetimes[i] > 1) {
          streakLifetimes[i] = 0;
          streakPosArr[o] = (random() - 0.5) * 12;
          streakPosArr[o + 1] = (random() - 0.5) * 12;
          streakPosArr[o + 2] = random() * -12;
        }
        streakPosArr[o] += streakVelocities[o] * delta * (1 + warpIntensity * 4);
        streakPosArr[o + 1] += streakVelocities[o + 1] * delta * (1 + warpIntensity * 4);
        streakPosArr[o + 2] += streakVelocities[o + 2] * delta * (1 + warpIntensity * 4);
        const lifeFade =
          streakLifetimes[i] < 0.15
            ? streakLifetimes[i] / 0.15
            : streakLifetimes[i] > 0.85
              ? (1 - streakLifetimes[i]) / 0.15
              : 1;
        const c = new THREE.Color().setRGB(
          streakColArr[o],
          streakColArr[o + 1],
          streakColArr[o + 2],
        );
        c.multiplyScalar(lifeFade * (0.5 + warpIntensity * 0.5));
        streakColArr[o] = c.r;
        streakColArr[o + 1] = c.g;
        streakColArr[o + 2] = c.b;
      }
      streakGeo.attributes.position.needsUpdate = true;
      streakGeo.attributes.color.needsUpdate = true;

      /* Core */
      core.rotation.y += delta * 0.2 * motionScale;
      core.rotation.z -= delta * 0.1 * motionScale;
      core.scale.setScalar(1 + Math.sin(elapsed * 1.3) * 0.03 * motionScale);
      coreHalo1.rotation.z += delta * 0.12 * motionScale;
      coreHalo2.rotation.z -= delta * 0.08 * motionScale;
      coreHalo3.rotation.z += delta * 0.15 * motionScale;

      /* Stars */
      stars.rotation.y = Math.sin(elapsed * 0.06) * 0.012 * motionScale;

      /* Planet tracking labels */
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      solar.planets.forEach((p, idx) => {
        const el = labelRefs.current[idx];
        if (!el) return;
        projVec.copy(p.group.position).project(camera);
        const dist = camera.position.distanceTo(p.group.position);
        const behind = projVec.z > 1;
        const inRange = !behind && dist < 150 && Math.abs(projVec.x) < 1.15 && Math.abs(projVec.y) < 1.15;
        if (!inRange) {
          el.classList.add("is-hidden");
          return;
        }
        el.classList.remove("is-hidden");
        const x = (projVec.x * 0.5 + 0.5) * vw;
        const y = (-projVec.y * 0.5 + 0.5) * vh;
        // offset above the planet's apparent disc
        const apparent = Math.max(30, (p.def.size / Math.max(1, dist)) * vh * 0.62);
        el.style.transform = `translate3d(${x.toFixed(1)}px,${(y - apparent).toFixed(1)}px,0) translate(-50%,-100%)`;
        const near = dist < 55;
        el.classList.toggle("is-near", near);
        const distEl = labelDistRefs.current[idx];
        if (distEl) distEl.textContent = `${Math.max(0, Math.round(dist * 4.2))} Mm`;
      });

      /* Minimap */
      drawMinimap(scrollProgress);

      /* Render */
      composer.render();
    };

    animate();

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("scroll", updateScrollTarget);
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("resize", handleResize);
      solar.dispose();
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Points || obj instanceof THREE.Line) {
          obj.geometry.dispose();
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          mats.forEach((m) => m.dispose());
        }
      });
      composer.dispose();
      renderer.dispose();
    };
  }, [loading]);

  const scrollToChapter = (index: number) => {
    document.getElementById(`chapter-${index}`)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth",
    });
  };

  return (
    <div className="journey-shell">
      {/* Loading Screen */}
      <div className={`loading-screen${loading ? "" : " is-hidden"}`}>
        <div className="loading-inner">
          <div className="loading-rings">
            <span />
            <span />
            <span />
          </div>
          <div className="loading-brand">
            KINETIC <i>/</i> CORE
          </div>
          <div className="loading-bar-track">
            <div className="loading-bar" />
          </div>
          <div className="loading-status">CHARTING PLANETARY ALIGNMENT</div>
          <div className="loading-worlds">
            MERCURY · VENUS · EARTH · MARS · JUPITER · SATURN · URANUS · NEPTUNE · PLUTO
          </div>
        </div>
      </div>

      {/* Glitch Overlay */}
      <div className="glitch-overlay" ref={glitchOverlayRef} aria-hidden="true">
        <div className="glitch-slice" />
        <div className="glitch-slice" />
        <div className="glitch-slice" />
      </div>

      {/* Progress Bar */}
      <div className="hud-progress-track" aria-hidden="true">
        <div className="hud-progress-bar" ref={progressBarRef} />
      </div>

      {/* Header HUD */}
      <nav className="hud-header" aria-label="Journey information">
        <div className="brand-lockup">
          <svg className="brand-symbol" viewBox="0 0 28 28" fill="none" aria-hidden="true">
            <path d="M14 1.5 26.5 14 14 26.5 1.5 14 14 1.5Z" />
            <path d="M14 7.5 20.5 14 14 20.5 7.5 14 14 7.5Z" />
            <circle cx="14" cy="14" r="1.4" />
          </svg>
          <span>
            KINETIC <i>/</i> CORE
          </span>
        </div>
        <div className="header-mode">
          <span className="signal-dot" />
          GRAND PLANETARY TOUR
        </div>
      </nav>

      {/* Scene Vignette + Canvas */}
      <div className="scene-vignette" aria-hidden="true" />
      <canvas className="webgl-canvas" ref={canvasRef} aria-hidden="true" tabIndex={-1} />

      {/* Planet tracking labels */}
      <div className="planet-label-layer" aria-hidden="true">
        {PLANETS.map((planet, idx) => (
          <div
            key={planet.id}
            className="planet-label is-hidden"
            ref={(el) => {
              labelRefs.current[idx] = el;
            }}
            style={{ ["--accent" as string]: chapters[planet.chapterIndex].accent }}
          >
            <span className="pl-name">{planet.name}</span>
            <span className="pl-rule" />
            <span
              className="pl-dist"
              ref={(el) => {
                labelDistRefs.current[idx] = el;
              }}
            >
              000 Mm
            </span>
          </div>
        ))}
      </div>

      {/* Chapter navigation */}
      <div className="chapter-nav" aria-label="Chapter navigation">
        {chapters.map((chapter, index) => (
          <button
            key={chapter.tag}
            type="button"
            className={`nav-dot${index === 0 ? " is-active" : ""}`}
            ref={(el) => {
              navRefs.current[index] = el;
            }}
            onClick={() => scrollToChapter(index)}
            aria-label={`Go to ${chapter.tag}`}
            data-label={chapter.planetId ? chapter.planetId.toUpperCase() : chapter.tag.split(" / ")[1]}
            style={{ ["--accent" as string]: chapter.accent }}
          >
            <span />
          </button>
        ))}
      </div>

      {/* Minimap */}
      <div className="minimap-container" aria-label="Path minimap">
        <canvas ref={minimapRef} />
        <div className="minimap-label">TOUR PATH</div>
      </div>

      {/* Bottom-right HUD */}
      <div className="scroll-hud-indicator" aria-label="Journey telemetry">
        <div className="hud-row">
          <span className="hud-label">PROGRESS</span>
          <span className="hud-value" ref={progressTextRef}>
            000.0%
          </span>
        </div>
        <div className="hud-row">
          <span className="hud-label">RANGE</span>
          <span className="hud-value" ref={rangeTextRef}>
            00.31 AU
          </span>
        </div>
        <div className="hud-row">
          <span className="hud-label">VELOCITY</span>
          <span className="hud-value hud-speed" ref={speedTextRef}>
            0000 u/s
          </span>
        </div>
        <div className="hud-row">
          <span className="hud-label">HEADING</span>
          <span className="hud-value" ref={headingTextRef}>
            000°
          </span>
        </div>
        <div className="hud-row">
          <span className="hud-label">PROXIMITY</span>
          <span className="hud-value hud-wide hud-proximity" ref={proximityTextRef}>
            DEEP SPACE
          </span>
        </div>
      </div>

      {/* Content Sections */}
      <main className="scroll-container">
        {chapters.map((chapter, index) => (
          <section
            className="content-section"
            id={`chapter-${index}`}
            key={chapter.tag}
            aria-label={chapter.tag}
          >
            <div
              className={`content-box${index === 0 ? " is-active" : ""}`}
              ref={(el) => {
                contentRefs.current[index] = el;
              }}
              style={{ ["--accent" as string]: chapter.accent }}
            >
              {index === 0 && (
                <div className="hero-brand" aria-label="Kinetic Core">
                  <span className="hero-brand-mark" aria-hidden="true">
                    <span />
                    <span />
                    <span />
                  </span>
                  <span>
                    KINETIC <i>/</i> CORE
                  </span>
                </div>
              )}
              <div className="tag">
                <span className="tag-rule" />
                {chapter.tag}
              </div>
              <h1>
                {chapter.title.map((line) => (
                  <span key={line}>{line}</span>
                ))}
              </h1>
              <p>{chapter.description}</p>
              {chapter.stats && (
                <div className="planet-stats">
                  {chapter.stats.map((stat) => (
                    <div className="stat-chip" key={stat.label}>
                      <span>{stat.label}</span>
                      <b>{stat.value}</b>
                    </div>
                  ))}
                </div>
              )}
              {index === 0 && (
                <button className="descent-button" onClick={() => scrollToChapter(1)}>
                  <span>BEGIN THE GRAND TOUR</span>
                  <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
                    <path d="M10 3.5v12M5.5 11l4.5 4.5 4.5-4.5" />
                  </svg>
                </button>
              )}
            </div>
          </section>
        ))}
      </main>
    </div>
  );
}
